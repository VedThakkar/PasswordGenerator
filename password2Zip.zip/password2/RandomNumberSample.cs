﻿using Microsoft.Data.SqlClient;
using System.Data;
class RandomNumberSample
{
    public static void Main(string[] args)
    {
        var watch = new System.Diagnostics.Stopwatch();
        watch.Start();
        Console.WriteLine("password insertion in progress...");
        const string CONNECTION_STRING = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=PasswordData;Integrated Security=True";
        SqlConnection conn = new SqlConnection(CONNECTION_STRING);
        string sql;
        SqlCommand cmd = new SqlCommand("sp_InsertPass", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Pass", SqlDbType.VarChar, 20);
        conn.Open();
        for (int i = 0; i < 100000; i++)
        {
            var pass = GeneratePassword(20);
            //Console.WriteLine($"password : {pass}");
            cmd.Parameters["@Pass"].Value = pass;
            //sql = $"Insert into [dbo].[PASSWORDTABLE](PASSWORDValue) values('{pass}')";
            //SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
        }
        watch.Stop();
        conn.Close();
        Console.WriteLine($"Execution Time: {(watch.ElapsedMilliseconds)/1000} SEC");
        Console.WriteLine("password insertion Completed...");
        Console.ReadLine();
    }
    // Default size of random password is 15
    public static string GeneratePassword(int lengthOfPassword)
    {
        const string LOWERCASE_CHARACTERS = "abcdefghijklmnopqrstuvwxyz";
        const string UPPERCASE_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const string NUMERIC_CHARACTERS = "0123456789";
        const string SPECIAL_CHARACTERS = @"!#$%&*@\";
        string characterSet = "";
        characterSet += LOWERCASE_CHARACTERS;
        characterSet += UPPERCASE_CHARACTERS;
        characterSet += NUMERIC_CHARACTERS;
        characterSet += SPECIAL_CHARACTERS;
        char[] password = new char[lengthOfPassword];
        int characterSetLength = characterSet.Length;
        System.Random random = new System.Random();
        for (int characterPosition = 0; characterPosition < lengthOfPassword; characterPosition++)
        {
            password[characterPosition] = characterSet[random.Next(characterSetLength - 1)];
        }
        return string.Join(null, password);
    }
}